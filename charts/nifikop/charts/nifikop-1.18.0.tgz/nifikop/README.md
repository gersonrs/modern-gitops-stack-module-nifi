# NiFiKop - Nifi Kubernetes operator Helm chart

This Helm chart install NiFiKop the Konpyūtāika's Nifi Kubernetes operator to create/configure/manage NiFi
clusters in a Kubernetes Namespace.

It will use Custom Ressources Definition CRDs:

- `nificlusters.nifi.konpyutaika.com`,
- `nifiusers.nifi.konpyutaika.com`,
- `nifiusergroups.nifi.konpyutaika.com`,
- `nifiregistryclients.nifi.konpyutaika.com`,
- `nifiparametercontexts.nifi.konpyutaika.com`,
- `nifidataflows.nifi.konpyutaika.com`,

which implements kubernetes custom ressource definition.

## Introduction

### Configuration

The following tables lists the configurable parameters of the NiFi Operator Helm chart and their default values.

| Parameter                        | Description                                                                                                                                                                          | Default                  |
| -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------ |
| `image.repository`               | Image                                                                                                                                                                                | `konpyutaika/nifikop`    |
| `image.tag`                      | Image tag                                                                                                                                                                            | `v1.18.0-release`        |
| `image.pullPolicy`               | Image pull policy                                                                                                                                                                    | `Always`                 |
| `image.imagePullSecrets.enabled` | Enable the use of secret for docker image                                                                                                                                            | `false`                  |
| `image.imagePullSecrets.name`    | Name of the secret to connect to docker registry                                                                                                                                     | -                        |
| `certManager.enabled`            | Enable cert-manager integration                                                                                                                                                      | `true`                   |
| `rbacEnable`                     | If true, create & use RBAC resources                                                                                                                                                 | `true`                   |
| `labels`                         | Labels to add to all deployed resources                                                                                                                                              | `{}`                     |
| `annotations`                    | Annotations to add to all deployed resources                                                                                                                                         | `{}`                     |
| `resources`                      | Pod resource requests & limits                                                                                                                                                       | `{}`                     |
| `metrics.enabled`                | deploy service for metrics                                                                                                                                                           | `false`                  |
| `metrics.port`                   | Set port for operator metrics                                                                                                                                                        | `8081`                   |
| `logLevel`                       | Log level to output                                                                                                                                                                  | `Info`                   |
| `logEncoding`                    | Log encoding to use. Either `json` or `console`                                                                                                                                      | `json`                   |
| `certManager.clusterScoped`      | If true setup cluster scoped resources                                                                                                                                               | `false`                  |
| `namespaces`                     | List of namespaces where the operator watches for custom resources. Empty means the release namespace only. Ignored when `watchAnyNamespace` is `true`.                             | `[]`                     |
| `watchAnyNamespace`              | Watch every namespace in the cluster. Leaves `WATCH_NAMESPACE` unset and binds the operator RBAC cluster-wide. Requires `createClusterScopedResources=true`.                         | `false`                  |
| `createClusterScopedResources`   | Create `ClusterRole`/`ClusterRoleBinding` resources. When `false`, only namespaced `Role`/`RoleBinding` are rendered in the watched namespaces (incompatible with `watchAnyNamespace` and `certManager.clusterScoped`). | `true`                   |
| `nodeSelector`                   | Node selector configuration for operator pod                                                                                                                                         | `{}`                     |
| `affinity`                       | Node affinity configuration for operator pod                                                                                                                                         | `{}`                     |
| `tolerations`                    | Toleration configuration for operator pod                                                                                                                                            | `{}`                     |
| `serviceAccount.create`          | Whether the SA creation is delegated to the chart or not                                                                                                                             | `true`                   |
| `serviceAccount.name`            | Name of the SA used for NiFiKop deployment                                                                                                                                           | release name             |
| `podSecurityContext`             | Pod security context for the operator pod                                                                                                                                            | `runAsUser: 1000`        |
| `securityContext`                | Container security context for the operator container                                                                                                                                | `allowPrivilegeEscalation=false` |
| `hostAliases`                    | Pod spec host aliases for the operator pod                                                                                                                                           | `[]`                     |
| `openshift.scc.create`           | Create a dedicated SCC for the operator on OpenShift. Only rendered when the cluster exposes `security.openshift.io/v1`.                                                            | `true`                   |
| `openshift.scc.existingName`     | Name of a pre-existing SCC to use instead of creating one. The chart grants the operator SA permission to use the named SCC.                                                        | `""`                     |
| `webhook.enabled`                | Enable the operator webhook                                                                                                                                                          | `true`                   |
| `webhook.tls.mode`               | How the webhook TLS cert is provided. One of `certManager`, `existingSecret`. Use `existingSecret` to bring your own pre-created TLS secret.                                         | `certManager`            |
| `webhook.tls.secretName`         | Shared compatibility override for the webhook TLS secret name. In `certManager` mode this sets the `Certificate` `secretName`; in `existingSecret` mode it names the pre-created secret. | `""`                     |
| `webhook.tls.certManager.createIssuer`     | When `mode=certManager`, create a namespaced self-signed `Issuer` for the webhook `Certificate`. Set to `false` to reference an existing Issuer/ClusterIssuer via `issuerRef`.             | `true`                   |
| `webhook.tls.certManager.issuerRef.name`   | Name of the cert-manager Issuer/ClusterIssuer used by the webhook `Certificate`. When `createIssuer=true` the chart also creates an Issuer with this name.                                 | `selfsigned-issuer`      |
| `webhook.tls.certManager.issuerRef.kind`   | Kind of the issuer referenced by the webhook `Certificate`. Use `ClusterIssuer` to bring your own cluster-scoped issuer; must be `Issuer` when `createIssuer=true`.                        | `Issuer`                 |
| `webhook.tls.certManager.issuerRef.group`  | API group of the issuer. Rendered on the `Certificate` only when set to a non-default value (e.g. `awspca.cert-manager.io`). Must be `cert-manager.io` when `createIssuer=true`.           | `cert-manager.io`        |
| `webhook.tls.certManager.secretName`       | Mode-specific override for the `Certificate` `secretName`. Takes precedence over `webhook.tls.secretName`.                                                                                | `""`                     |
| `webhook.tls.existingSecret.name`          | Mode-specific override for the pre-created TLS secret name. Takes precedence over `webhook.tls.secretName` in `existingSecret` mode.                                                       | `""`                     |
| `runAsUser`                      | Specify RunAsUser uid for NiFiKop operator pod                                                                                                                                       | `1000`                   |
| `additionalEnvs`                 | List of additional environment variables to set in the NiFiKop operator pod.                                                                                                         | `[]`                     |

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`. For example,

Alternatively, a YAML file that specifies the values for the above parameters can be provided while installing the chart. For example,

```console
$ helm install nifikop \
    oci://ghcr.io/konpyutaika/helm-charts/nifikop \
    -f values.yaml
```

### Installing the Chart

In the case where you don't want to deploy the crds using helm (`--skip-crds`) or you are using a version of kubernetes that is under 1.16, you need to deploy manually the crds beforehand:

```console
kubectl apply -f https://raw.githubusercontent.com/konpyutaika/nifikop/master/deploy/crds/v1beta1/nifi.konpyutaika.com_nificlusters_crd.yaml
kubectl apply -f https://raw.githubusercontent.com/konpyutaika/nifikop/master/deploy/crds/v1beta1/nifi.konpyutaika.com_nifiusers_crd.yaml
kubectl apply -f https://raw.githubusercontent.com/konpyutaikanifikop/master/deploy/crds/v1beta1/nifi.konpyutaika.com_nifiusergroups_crd.yaml
kubectl apply -f https://raw.githubusercontent.com/konpyutaika/nifikop/master/deploy/crds/v1beta1/nifi.konpyutaika.com_nifidataflows_crd.yaml
kubectl apply -f https://raw.githubusercontent.com/konpyutaika/nifikop/master/deploy/crds/v1beta1/nifi.konpyutaika.com_nifiparametercontexts_crd.yaml
kubectl apply -f https://raw.githubusercontent.com/konpyutaika/nifikop/master/deploy/crds/v1beta1/nifi.konpyutaika.com_nifiregistryclients_crd.yaml
```

You can make a dry run of the chart before deploying:

```console
helm install nifikop konpyutaika-incubator/nifikop \
    --dry-run \
    --debug.enabled \
    --set logLevel="Debug" \
    --set namespaces={"nifikop"}
```

To install the chart with the release name `nifikop`:

```console
$ helm install nifikop konpyutaika-incubator/nifikop --set namespaces={"nifikop"}
```

We can surcharge default parameters using `--set` flag:

```console
$ helm install nifikop konpyutaika-incubator/nifikop --replace --set image.tag=asyncronous
```

> the `--replace` flag allow you to reuses a charts release name

### Watched namespaces and RBAC

By default the operator watches the namespace it is installed in. To watch a fixed set of namespaces:

```console
$ helm install nifikop konpyutaika-incubator/nifikop --set namespaces={"nifi","data"}
```

To watch every namespace in the cluster:

```console
$ helm install nifikop konpyutaika-incubator/nifikop --set watchAnyNamespace=true
```

Namespaced permissions are defined once as a `ClusterRole` and bound with a `RoleBinding` in each watched
namespace, or with a single `ClusterRoleBinding` when `watchAnyNamespace=true`. A second `ClusterRole` grants
read access to `namespaces` and `nodes` (and `clusterissuers` when `certManager.clusterScoped=true`), which the
operator needs regardless of the watched namespaces.

If cluster-scoped RBAC is not permitted in your cluster, set `createClusterScopedResources=false` to render a
`Role`/`RoleBinding` pair in each watched namespace instead. This mode cannot watch all namespaces.

### OpenShift

For OpenShift deployments the chart can create a dedicated SecurityContextConstraints resource
for the operator pod. This is gated on the `security.openshift.io/v1` API being present.

- `openshift.scc.create=true` (default) creates and binds a dedicated SCC.
- To use a pre-existing SCC instead, set `openshift.scc.create=false` and `openshift.scc.existingName=<your-scc>`.
- The same OCI install command works on OpenShift. The OpenShift-specific part is just the values you pass to Helm.

### Listing deployed charts

```
helm list
```

### Webhook TLS configuration

The chart keeps the default self-signed cert-manager flow unchanged. With `certManager.enabled=true` and `webhook.tls.mode=certManager`, it creates a self-signed `Issuer`, creates a webhook `Certificate`, and mounts the resulting secret into the operator deployment.

For backward compatibility, the shared `webhook.tls.secretName` value still works in both modes. The newer mode-specific keys `webhook.tls.certManager.secretName` and `webhook.tls.existingSecret.name` are also supported and take precedence when set.

To reuse an existing cert-manager `ClusterIssuer`, disable the chart-created `Issuer` and point the webhook `Certificate` at the issuer you already manage:

```yaml
certManager:
  enabled: true

webhook:
  enabled: true
  tls:
    mode: certManager
    secretName: nifikop-webhook-tls
    certManager:
      createIssuer: false
      issuerRef:
        name: corp-platform-cluster-issuer
        kind: ClusterIssuer
        group: cert-manager.io
```

To bring your own webhook serving certificate secret, switch to `existingSecret` mode. Either the legacy shared `secretName` key or the mode-specific `existingSecret.name` key can be used:

```yaml
webhook:
  enabled: true
  tls:
    mode: existingSecret
    secretName: nifikop-webhook-precreated-tls
```

`certManager` mode manages a webhook `Certificate` resource for you. `existingSecret` mode only mounts an already-created TLS secret into the operator pod.

If you rely on cert-manager CA injection for conversion webhook trust, keep using `certManager` mode or manage CA bundle injection separately. The Helm chart does not template CRD conversion webhook CA annotations today, and `existingSecret` mode intentionally skips creating the `Certificate` resource that cert-manager would normally watch for `inject-ca-from`.

### Get Status for the helm deployment

```
helm status nifikop
```

## Uninstaling the Charts

If you want to delete the operator from your Kubernetes cluster, the operator deployment
should be deleted.

```
$ helm del nifikop
```

The command removes all the Kubernetes components associated with the chart and deletes the helm release.

> The CRD created by the chart are not removed by default and should be manually cleaned up (if required)

Manually delete the CRD:

```
kubectl delete crd nificlusters.nifi.konpyutaika.com
kubectl delete crd nifiusers.nifi.konpyutaika.com
kubectl delete crd nifiusergroups.nifi.konpyutaika.com
kubectl delete crd nifiregistryclients.nifi.konpyutaika.com
kubectl delete crd nifiparametercontexts.nifi.konpyutaika.com
kubectl delete crd nifidataflows.nifi.konpyutaika.com
```

> **!!!!!!!!WARNING!!!!!!!!**
>
> If you delete the CRD then **!!!!!!WAAAARRRRNNIIIIINNG!!!!!!**
>
> It will delete **ALL** Clusters that has been created using this CRD!!!
>
> Please never delete a CRD without very very good care

Helm always keeps records of what releases happened. Need to see the deleted releases? `helm ls --deleted`
shows those, and `helm ls --all` shows all of the releases (deleted and currently deployed, as well as releases that
failed):

Because Helm keeps records of deleted releases, a release name cannot be re-used. (If you really need to re-use a
release name, you can use the `--replace` flag, but it will simply re-use the existing release and replace its
resources.)

Note that because releases are preserved in this way, you can rollback a deleted resource, and have it re-activate.

To purge a release

```console
helm del nifikop
```

## Troubleshooting

### Install of the CRD

By default, the chart will install the CRDs, but this installation is global for the whole
cluster, and you may want to not modify the already deployed CRDs.

In this case there is a parameter to say to not install the CRDs:

```
$ helm install --name nifikop ./helm/nifikop --set namespaces={"nifikop"} --skip-crds
```
